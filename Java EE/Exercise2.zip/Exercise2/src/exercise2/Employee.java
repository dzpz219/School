package exercise2;

/**
 *
 * @author Danny
 */
public class Employee
    {
        private String name; // instance variable to store name
        // method to set the name in the object
        public void setName(String name)
        {
            this.name = name; // store the name
        }
        // method to retreive (get) the name from the object
        public String getName()
        {
            return name;
        }
}
