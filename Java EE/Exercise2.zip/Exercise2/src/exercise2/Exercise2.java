package exercise2;

import java.util.Scanner;

/**
 *
 * @author Danny
 */
public class Exercise2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // Create a new instance of Employee class
        Employee Emp = new Employee();
        
        // Propmt user to enter a String variable for name
        System.out.println("Enter Name: ");
        Scanner Scan = new Scanner(System.in);
        
        // Set employee name
        Emp.setName(Scan.nextLine());
        
        // Output employee name using getName method
        System.out.println("Employee name is: " + Emp.getName());
        System.out.println("Program by Chao Zhang, 000306946");
    }
    
}
