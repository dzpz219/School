/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mohawkcollege.cz;

import java.util.Calendar;
import java.util.Currency;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.RequestScoped;
import javax.inject.Named;

/**
 *
 * @author Danny
 */
@ManagedBean
@Named(value = "payment")
@RequestScoped

public class Payment {
    
    public Payment() {
    }
    
    public Payment(Calendar date, Currency balance, Currency interest, Currency principle, Currency payment) {
        this.date = date;
        this.balance = balance;
        this.interest = interest;
        this.principle = principle;
        this.payment = payment;
    }
    
    private Calendar date;

    /**
     * Get the value of date
     *
     * @return the value of date
     */
    
    public String getDate() {
        Calendar cal = date;
        
        String year = Integer.toString(cal.get(Calendar.YEAR));
        String month = Integer.toString(cal.get(Calendar.MONTH));
        String day = Integer.toString(cal.get(Calendar.DAY_OF_MONTH));
          
        return  day + month + year;
    }

    /**
     * Set the value of date
     *
     * @param date new value of date
     */
    public void setDate(Calendar date) {
        this.date = date;
    }

    private Currency balance;

    /**
     * Get the value of balance
     *
     * @return the value of balance
     */
    public Currency getBalance() {
        return balance;
    }

    /**
     * Set the value of balance
     *
     * @param balance new value of balance
     */
    public void setBalance(Currency balance) {
        this.balance = balance;
    }

    private Currency interest;

    /**
     * Get the value of interest
     *
     * @return the value of interest
     */
    public Currency getInterest() {
        return interest;
    }

    /**
     * Set the value of interest
     *
     * @param interest new value of interest
     */
    public void setInterest(Currency interest) {
        this.interest = interest;
    }

    private Currency principle;

    /**
     * Get the value of principle
     *
     * @return the value of principle
     */
    public Currency getPrinciple() {
        return principle;
    }

    /**
     * Set the value of principle
     *
     * @param principle new value of principle
     */
    public void setPrinciple(Currency principle) {
        this.principle = principle;
    }

    private Currency payment;

    /**
     * Get the value of payment
     *
     * @return the value of payment
     */
    public Currency getPayment() {
        return payment;
    }

    /**
     * Set the value of payment
     *
     * @param payment new value of payment
     */
    public void setPayment(Currency payment) {
        this.payment = payment;
    }

}
