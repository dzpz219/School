/*
 * StAuth10066: I Chao Zhang, 000306946 certify that this material is my original work. 
 * No other person's work has been used without due acknowledgement. 
 * I have not made my work available to anyone else.
 */
package com.mohawkcollege.cz;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.RequestScoped;
import javax.inject.Named;

/**
 *
 * @author Danny
 */
@ManagedBean
@Named(value = "mortgage")
@RequestScoped
public class Mortgage {
    /**
     * Creates a new instance of Mortgage
     */
    public Mortgage() {
    }
    private double interestRate;
    private double amortizationPeriod;
    private double amount;
    private double calculatedMonthlyRate;
    private double effectiveAnnualRate;
    private Payment[] payments[];  
    private double totalInterest;
    private double totalAmount;
    
    /**
     * Get the value of totalInterest
     *
     * @return the value of totalInterest
     */
    public double getTotalInterest() {
        totalInterest = getTotalAmount() - amount;
        return totalInterest;
    }

    /**
     * Get the value of totalAmount
     *
     * @return the value of totalAmount
     */
    public double getTotalAmount() {
        double interest = getCalculatedMonthlyRate();
        totalAmount = ((interest * amount)/(1-(Math.pow(1+interest, -(amortizationPeriod * 12)))) * amortizationPeriod * 12);
        return totalAmount;
    }


    /**
     * Get the value of calculatedSemiAnnualRate
     *
     * @return the value of calculatedSemiAnnualRate
     */
    public double getEffectiveAnnualRate() {
        effectiveAnnualRate = (Math.pow((1 + (Math.pow(interestRate/2, 2) + interestRate)), 1/12) - 1) * 12;
        return effectiveAnnualRate;
    }

    

    /**
     * Get the value of calculatedMonthlyRate
     *
     * @return the value of calculatedMonthlyRate
     */
    public double getCalculatedMonthlyRate() {
        calculatedMonthlyRate = Math.pow((1 + (Math.pow(interestRate/2, 2) + interestRate)), 1/12) - 1;
        return calculatedMonthlyRate;
    }

    

    /**
     * Get the value of amount
     *
     * @return the value of amount
     */
    public double getAmount() {
        return amount;
    }

    /**
     * Set the value of amount
     *
     * @param amount new value of amount
     */
    public void setAmount(double amount) {
        this.amount = amount;
    }

    

    /**
     * Get the value of amortizationPeriod
     *
     * @return the value of amortizationPeriod
     */
    public double getAmortizationPeriod() {
        return amortizationPeriod;
    }

    /**
     * Set the value of amortizationPeriod
     *
     * @param amortizationPeriod new value of amortizationPeriod
     */
    public void setAmortizationPeriod(double amortizationPeriod) {
        this.amortizationPeriod = amortizationPeriod;
    }

    

    /**
     * Get the value of interestRate
     *
     * @return the value of interestRate
     */
    public double getInterestRate() {
        return interestRate;
    }

    /**
     * Set the value of interestRate
     *
     * @param interestRate new value of interestRate
     */
    public void setInterestRate(double interestRate) {
        this.interestRate = interestRate;
    }    
}
