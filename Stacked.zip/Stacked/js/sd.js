
$(document).ready(function() {
	var featureImage = $('.featureImage').waypoint(function() {
	  $('.featureImage').addClass('showUp');
	})

	var leftFade = $('.heading-left').waypoint(function() {
	  $('.heading-left').addClass('left-fade-in');
	}, {
		offset: '75%'
	})

	var rightFade = $('.heading-right').waypoint(function() {
	  $('.heading-right').addClass('right-fade-in');
	}, {
		offset: '75%'
	})
});
