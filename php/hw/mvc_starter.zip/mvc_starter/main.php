<?php

require_once ('public/main.php');

?>