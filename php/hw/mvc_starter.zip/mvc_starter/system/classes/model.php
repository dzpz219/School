<?
class Model {
    
	function __construct() {
	}
	
	 
	
	
    }
    
    
?>