package com.example.lab3;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.app.Activity;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends Activity {
	
	public TextView textview;
	public int orientation;
	public String msg;
	public String buildVersion;
	
	private View mContentView;
	private View mLoadingView;
	private int mShortAnimationDuration;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		textview = (TextView) findViewById(R.id.textView1);
		msg = "This device is currently held in ";
		buildVersion = "My API Build version is " + Build.VERSION.SDK_INT;
		orientation = getResources().getConfiguration().orientation;
		if (orientation == 1){
			msg += "Portrait Orientation. " + buildVersion;
		}
		else {
			msg += "Landscape Orientation. " + buildVersion;
		}
		textview.setText(msg);
		
		 mContentView = findViewById(R.id.imageView1);
	        mLoadingView = findViewById(R.id.imageView2);

	        // Initially hide the content view.
	        mContentView.setVisibility(View.GONE);

	        // Retrieve and cache the system's default "short" animation time.
	        mShortAnimationDuration = getResources().getInteger(
	                android.R.integer.config_shortAnimTime);
	}
	
	public void secondActivity(View view){
		Intent intent = new Intent(this, SecondActivity.class);
		startActivity(intent);
	}
	
	private void crossfade() {

	    // Set the content view to 0% opacity but visible, so that it is visible
	    // (but fully transparent) during the animation.
	    mContentView.setAlpha(0f);
	    mContentView.setVisibility(View.VISIBLE);

	    // Animate the content view to 100% opacity, and clear any animation
	    // listener set on the view.
	    mContentView.animate()
	            .alpha(1f)
	            .setDuration(mShortAnimationDuration)
	            .setListener(null);

	    // Animate the loading view to 0% opacity. After the animation ends,
	    // set its visibility to GONE as an optimization step (it won't
	    // participate in layout passes, etc.)
	    mLoadingView.animate()
	            .alpha(0f)
	            .setDuration(mShortAnimationDuration)
	            .setListener(new AnimatorListenerAdapter() {
	                @Override
	                public void onAnimationEnd(Animator animation) {
	                    mLoadingView.setVisibility(View.GONE);
	                }
	            });
	}
}
