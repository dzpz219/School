/** Automatically generated file. DO NOT MODIFY */
package com.example.lab6a;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}